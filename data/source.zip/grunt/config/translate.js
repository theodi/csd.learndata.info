module.exports = function (grunt) {

    return {
        masterLang: "en",
        targetLang: null,
        format: "csv",
        csvDelimiter: ",",
        "shouldReplaceExisting": false
    };

};
